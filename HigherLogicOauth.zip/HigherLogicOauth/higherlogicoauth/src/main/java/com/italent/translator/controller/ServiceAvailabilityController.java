package com.italent.translator.controller;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.RequestScope;

@RestController
@RequestMapping("/higher-logic")
@CrossOrigin
@RequestScope
public class ServiceAvailabilityController {

    //private static final Logger logger = LogManager.getLogger(ServiceAvailabilityController.class);
    
    /**
     * To check availability of service
     * 
     * @return
     */
    @GetMapping("/availability")
    public ResponseEntity<String> serverReachable() {
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.setContentType(MediaType.APPLICATION_JSON);
        String response = "HL translation Backend Service is alive";
        return new ResponseEntity<>(response, responseHeaders, HttpStatus.OK);
    }
}


