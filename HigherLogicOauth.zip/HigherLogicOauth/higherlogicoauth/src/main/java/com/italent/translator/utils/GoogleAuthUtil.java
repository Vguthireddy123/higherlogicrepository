package com.italent.translator.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class GoogleAuthUtil {

	@Value("${app.refreshToken}")
	private String refreshToken;
	@Value("${app.client_id}")
	private String client_id;
	@Value("${app.client_secret}")
	private String client_secret;
	public 	String generateAccessToken() throws ClientProtocolException, IOException {
			
		HttpPost post = new HttpPost("https://oauth2.googleapis.com/token");
		String token=null;
		// add request parameter, form parameters
		List<NameValuePair> urlParameters = new ArrayList<>();
		urlParameters.add(new BasicNameValuePair("refresh_token", refreshToken));
		urlParameters.add(new BasicNameValuePair("client_id", client_id));
		urlParameters.add(new BasicNameValuePair("client_secret", client_secret));
		urlParameters.add(new BasicNameValuePair("grant_type", "refresh_token"));
		post.setEntity(new UrlEncodedFormEntity(urlParameters));
	
		try (CloseableHttpClient httpClient = HttpClients.createDefault();
				CloseableHttpResponse postRes = httpClient.execute(post)) {
	
			token = EntityUtils.toString(postRes.getEntity());
		}
		JSONObject obj=new JSONObject(token);
		return obj.getString("access_token");
	}
		
}
