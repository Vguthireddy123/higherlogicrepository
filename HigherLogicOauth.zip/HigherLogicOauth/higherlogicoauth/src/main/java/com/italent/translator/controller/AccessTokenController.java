package com.italent.translator.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.italent.translator.model.Response;

@RestController
@CrossOrigin
@RequestMapping("/higher-logic")
public class AccessTokenController {
	@Value("${app.refreshToken}")
	private String refreshToken;
	@Value("${app.client_id}")
	private String client_id;
	@Value("${app.client_secret}")
	private String client_secret;

	private static final Logger logger = LoggerFactory.getLogger(AccessTokenController.class);

	@GetMapping("/get-access-token")
	@ResponseBody
	public ResponseEntity<String>  regenerateToken(@RequestParam("data") String key)
			throws ClientProtocolException, IOException, ParseException {
		HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.setContentType(MediaType.APPLICATION_JSON);
		  Response response=new Response();
		 if(key == null || key.isEmpty())
		{
			 String res=response.errorResponse("Unautherized Access", 401);
			 
			 return new ResponseEntity<String>(res, responseHeaders, HttpStatus.BAD_REQUEST);
		}
		else {
			Base64.Decoder decoder=Base64.getDecoder();
			String decodeStr=new String(decoder.decode(key));
			String[] arrOfStr = decodeStr.split("_", 2);
			String sourceTimeStr = arrOfStr[1];
			Date sourceTime=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss",Locale.ENGLISH).parse(sourceTimeStr); 
			Date date = new Date();
			DateFormat  dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss",Locale.ENGLISH);
			dateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
			String currentTime= dateFormat.format(date);
			Date toDate=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss",Locale.ENGLISH).parse(currentTime); 
			long diff=toDate.getTime() - sourceTime.getTime();
			int seconds = (int) diff / 1000;
			logger.info("Diff between source and current time is: "+seconds);
			if(seconds > 120) {
				String session=response.errorResponse("Unautherized Access", 401);
				logger.info("Inside if");
				 return new ResponseEntity<String>(session, responseHeaders, HttpStatus.BAD_REQUEST);
			}
			
			
			HttpPost post = new HttpPost("https://oauth2.googleapis.com/token");
			String token=null;
			// add request parameter, form parameters
			List<NameValuePair> urlParameters = new ArrayList<>();
			urlParameters.add(new BasicNameValuePair("refresh_token", refreshToken));
			urlParameters.add(new BasicNameValuePair("client_id", client_id));
			urlParameters.add(new BasicNameValuePair("client_secret", client_secret));
			urlParameters.add(new BasicNameValuePair("grant_type", "refresh_token"));
			post.setEntity(new UrlEncodedFormEntity(urlParameters));
	
			try (CloseableHttpClient httpClient = HttpClients.createDefault();
					CloseableHttpResponse postRes = httpClient.execute(post)) {
	
				token = EntityUtils.toString(postRes.getEntity());
				logger.info("Access token " + token);
			}
			JSONObject obj=new JSONObject(token);
			String accessToken=obj.getString("access_token");
	         String successRes=response.successResponse(accessToken, "success");
			
	         return new ResponseEntity<String> (successRes, responseHeaders, HttpStatus.OK);
			}
		}   
	
		}

	
	
	
