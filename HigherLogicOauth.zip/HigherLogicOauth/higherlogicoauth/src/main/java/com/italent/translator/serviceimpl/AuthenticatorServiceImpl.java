package com.italent.translator.serviceimpl;
import java.text.ParseException;
import java.util.Base64;
import java.util.Date;
import java.util.TimeZone;

import org.apache.commons.lang3.time.DateParser;
import org.apache.commons.lang3.time.FastDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.italent.translator.service.AuthenticatorService;

@Service
public class AuthenticatorServiceImpl implements AuthenticatorService{
	
	 private static final Logger logger=LoggerFactory.getLogger(AuthenticatorServiceImpl.class);
	 
	 @Value("${app.token_validity_time}")
	 private int tokenValidityTime;
	
	@Override
	public boolean validateToken(String token) {
		
		if(token == null) {
			// this field can't be empty
			return false;
		}else {
			Base64.Decoder decoder=Base64.getDecoder();
			String decodedToken=null;
			String sourceTime=null;
			boolean validateTime=false;
			try {
				decodedToken=new String(decoder.decode(token));
				String[] arrOfDecodedTokenStr = decodedToken.split("_", 2);
				sourceTime = arrOfDecodedTokenStr[1];
				validateTime=validateTime(sourceTime);
				if(validateTime) {
					return true;
				}
				return validateTime;
				 
			}catch(IllegalArgumentException iae) {
				 logger.info("IllegalArgumentException: "+iae);
				 return false;
			}
		   catch (ArrayIndexOutOfBoundsException e) {
				logger.info("ArrayIndexOutOfBoundsException "+e);
				 return false;
			}
		}
		
	}
	
	public boolean validateTime(String fromTime) {
		
		DateParser dateParser = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
		Date sourceTime;
		try {
			   sourceTime = dateParser.parse(fromTime);
			   logger.info("source time: " + sourceTime);
			   Date date = new Date();
			   FastDateFormat dateFormat = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("UTC"));
			   String currentTime= dateFormat.format(date);
		      
		       DateParser dateparser = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss");
			   Date toDate=dateparser.parse(currentTime);
			   
			   logger.info("current time: " + toDate); 
			   long diff=toDate.getTime() - sourceTime.getTime();
			   int diffSeconds = (int) diff / 1000;
			   logger.info("Diff between source and current time is: "+diffSeconds);
			   logger.info("validity time: "+tokenValidityTime);
			   return tokenValidityTime > diffSeconds;
			   
		} catch (ParseException e) {
			logger.info("Got error in validate time" +e);
			return false;
			
		}
		
	}
	
}
