package com.italent.translator.model;

import org.json.JSONException;
import org.json.JSONObject;

public class Response {
	
	public String errorResponse(String errorMessage, int code) throws JSONException {
		 JSONObject errorResponse = new JSONObject();
		 errorResponse.put("errorMessage", errorMessage);
			errorResponse.put("statusCode", code);
			return errorResponse.toString();
		
	}
	public String successResponse(String access_token,String  status) throws JSONException
	{
		JSONObject successResponse = new JSONObject();
		successResponse.put("access_token", access_token);
		successResponse.put("status", status);
		return successResponse.toString();
		
	}
	

}
