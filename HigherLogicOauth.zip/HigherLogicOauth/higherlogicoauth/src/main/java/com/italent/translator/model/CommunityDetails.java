//package com.italent.translator.model;
//
//import java.util.Date;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="community_details")
//public class CommunityDetails {
//	@Id
//	@GeneratedValue(strategy = GenerationType.AUTO)
//	@Column(name="id")
//	private int id;
//	
//	@Column(name="community_domain",columnDefinition = "varchar(512)")
//	private String communityDomain;
//	
//	@Column(name="service_provider",columnDefinition = "varchar(100)")
//	private String serviceProvider;
//	
//	@Column(name="time_stamp")
//	private Date timeStamp;
//	
//	 @Column(name = "key_valut_name")
//	    private String keyValutKey;
//
//	 @Column(name = "key_valut_versionid")
//	    private String keyValutVersionId;	
//
//	 
//
//	private CommunityDetails(int id, String communityDomain, String serviceProvider, Date timeStamp, String keyValutKey,
//			String keyValutVersionId) {
//		super();
//		this.id = id;
//		this.communityDomain = communityDomain;
//		this.serviceProvider = serviceProvider;
//		this.timeStamp = timeStamp;
//		this.keyValutKey = keyValutKey;
//		this.keyValutVersionId = keyValutVersionId;
//	}
//
//
//
//	/**
//	 * @return the id
//	 */
//	public int getId() {
//		return id;
//	}
//
//
//
//	/**
//	 * @param id the id to set
//	 */
//	public void setId(int id) {
//		this.id = id;
//	}
//
//
//
//	/**
//	 * @return the communityDomain
//	 */
//	public String getCommunityDomain() {
//		return communityDomain;
//	}
//
//
//
//	/**
//	 * @param communityDomain the communityDomain to set
//	 */
//	public void setCommunityDomain(String communityDomain) {
//		this.communityDomain = communityDomain;
//	}
//
//
//
//	/**
//	 * @return the serviceProvider
//	 */
//	public String getServiceProvider() {
//		return serviceProvider;
//	}
//
//
//
//	/**
//	 * @param serviceProvider the serviceProvider to set
//	 */
//	public void setServiceProvider(String serviceProvider) {
//		this.serviceProvider = serviceProvider;
//	}
//
//
//
//	/**
//	 * @return the timeStamp
//	 */
//	public Date getTimeStamp() {
//		return timeStamp;
//	}
//
//
//
//	/**
//	 * @param timeStamp the timeStamp to set
//	 */
//	public void setTimeStamp(Date timeStamp) {
//		this.timeStamp = timeStamp;
//	}
//
//
//
//	/**
//	 * @return the keyValutKey
//	 */
//	public String getKeyValutKey() {
//		return keyValutKey;
//	}
//
//
//
//	/**
//	 * @param keyValutKey the keyValutKey to set
//	 */
//	public void setKeyValutKey(String keyValutKey) {
//		this.keyValutKey = keyValutKey;
//	}
//
//
//
//	/**
//	 * @return the keyValutVersionId
//	 */
//	public String getKeyValutVersionId() {
//		return keyValutVersionId;
//	}
//
//
//
//	/**
//	 * @param keyValutVersionId the keyValutVersionId to set
//	 */
//	public void setKeyValutVersionId(String keyValutVersionId) {
//		this.keyValutVersionId = keyValutVersionId;
//	}
//
//
//
//	/**
//	 * 
//	 */
//	public CommunityDetails() {
//		super();
//	}
//	
//	
//}
