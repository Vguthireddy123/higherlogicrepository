package com.italent.translator.service;

public interface AuthenticatorService {
	
	boolean validateToken(String token);
}
