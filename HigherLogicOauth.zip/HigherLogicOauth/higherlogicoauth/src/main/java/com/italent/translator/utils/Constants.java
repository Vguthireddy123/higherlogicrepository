package com.italent.translator.utils;

import org.springframework.beans.factory.annotation.Value;

public class Constants {
	public static String GOOGLE_V2_API = "https://translation.googleapis.com/language/translate/v2";
	@Value("app.project_id")
	public static String ALLOWED_ORIGINS;
}
