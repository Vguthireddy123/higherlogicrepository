//package com.italent.translator.service;
//
//import com.microsoft.azure.keyvault.SecretIdentifier;
//
//public interface KeyVaultService {
//	SecretIdentifier createKey(String keyName, String keyValue);
//	String fetchKey(String keyName, String versionId);
//
//}
