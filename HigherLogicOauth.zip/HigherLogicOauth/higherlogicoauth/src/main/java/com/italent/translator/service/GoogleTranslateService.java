package com.italent.translator.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

public interface GoogleTranslateService {
	
	String translateContent(String projectId, String targetLanguage, String text)
			throws RuntimeException, UnsupportedEncodingException, IOException;
}
