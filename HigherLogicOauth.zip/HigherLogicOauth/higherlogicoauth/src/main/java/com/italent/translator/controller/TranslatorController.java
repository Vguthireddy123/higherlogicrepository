package com.italent.translator.controller;

import javax.servlet.http.HttpServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.italent.translator.model.TranslateRequestBody;
import com.italent.translator.service.AuthenticatorService;
import com.italent.translator.service.GoogleTranslateService;
import com.italent.translator.utils.Response;

@RestController
@CrossOrigin
@RequestMapping("/higher-logic")
public class TranslatorController  extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	@Value("${app.project_id}")
	private String project_id;
	
	private static final Logger logger = LoggerFactory.getLogger(TranslatorController.class);
	
	@Autowired
	private GoogleTranslateService googleTranslateService;
	 
	@Autowired
	private AuthenticatorService authService;
	 
	@PostMapping(value="translate",consumes = "application/json")
	@ResponseBody
	public ResponseEntity<Response> getHtmlContent(@RequestBody TranslateRequestBody requestBody, @RequestHeader("token") String token ) {
		
		logger.info("In translator service method");
		try {
			
			if(token == null && requestBody == null) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(prepareResponse("error","Missing request body or header parameters"));
			}else {
				boolean validateToken=this.authService.validateToken(token);
				
				if(validateToken) {
					String content=requestBody.getContent();
					String targetLanguage=requestBody.getTargetLanguage();
					String result=this.googleTranslateService.translateContent(project_id, targetLanguage, content);
					
					
				    return ResponseEntity.status(HttpStatus.OK).body(prepareResponse("success",result));
				}else{
					return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(prepareResponse("error","Invalid token"));
				}
			}
		}catch (Exception ex) {
			logger.error("Got exception while parsing: "+ex);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(prepareResponse("error","Html parse error"));
		}
	}
	public Response prepareResponse(String status,String message) {
		Response response=new Response();
		response.setStatus(status);
		response.setMessage(message);
		return response;
	}
	
	
}
